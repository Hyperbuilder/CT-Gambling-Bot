//const mongoose = require('mongoose')
//
//const reqString = {
//type: String,
//required: True
//}
//
//cons profile-Schema = mongoose.Schema({
//guildId: reqString,
//userId: reqString,
//coins: {
//type: Number,
//requird: true
//
//}
//
//
//})
//
//
//
//
//
//
//
//
//
//
//
//
//